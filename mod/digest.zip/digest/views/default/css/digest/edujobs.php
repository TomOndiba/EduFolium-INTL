<?php
	/**
	* Edujobs CSS for the Digest message
	*/
?>

.digest-job {
	padding: 10px 0px;
	display: inline-block;
	width: 100%;
}

.digest-job img {
	padding: 0px 0px 0 0;
}

.digest-job h4 {
	padding-bottom: 5px;
}

.digest-job h4 a{
	text-decoration: none;
}
