<?php
	/**
	* Profile CSS for the Digest message
	*/
?>

.digest-profile {
	width: 100%;
	border-collapse: collapse;
}

.digest-profile td {
	width: 33%;
	padding: 10px;
	text-align: center;
	vertical-align: top;
}

.digest-profile tr {
	border-bottom: 1px dotted #dbdbdb;
}