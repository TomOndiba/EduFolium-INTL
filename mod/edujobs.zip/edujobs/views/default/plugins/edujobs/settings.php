<?php
/**
 * Elgg edujobs plugin
 * @package EduFolium
 */
	
    $plugin = $vars["entity"];
