<?php
/**
 * Elgg edujobs plugin
 * @package EduFolium
 */

$tabs = array(

);

echo elgg_view('navigation/tabs', array('tabs' => $tabs));
