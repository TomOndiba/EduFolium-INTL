******* EduJobs Plugin *******

Edu Jobs Plugin for EduFolium
