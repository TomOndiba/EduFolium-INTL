<?php
/**
 * Elgg kanelggamapsapi plugin
 * @package KanelggaMapsApi 
 */

echo elgg_view_form('kanelggamapsapi/admin/global_options');
