<?php
/**
 * Elgg kanelggamapsapi plugin
 * @package KanelggaMapsApi 
 */
 ?>

#map    {
    border: 1px solid #333;
    margin-top: 0.6em;
    overflow:hidden;
}

div.infowindow	{
	width:150px; 
	padding: 3px; 
	border:0px solid #eaeaea;
	height:70px;
	overflow-x:hidden; 	
}
