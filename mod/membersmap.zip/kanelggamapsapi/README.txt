******* KanelggaMapsApi Plugin *******

Elgg plugin containing php and js libraries for MembersMap and GroupsMap plugins.

== Installation ==
Requires: Elgg 1.8 or higher

1. Upload kanelggamapsapi in "/mod/" elgg folder
2. Activate the plugin in the administration panel
3. "In Administration/Configure/Settings/Kanellga Maps Api" you can enter Google API key (not required) and basic map options






