<?php
	/* SPANISH by GEAR invent! */
	
	$spa = array(
		'html_email_handler' => "Manejador de E-mail con HMTL",
		
		'html_email_handler:theme_preview:menu' => "Notificaciones HTML",
		
		// settings - configuraciones
		
		'html_email_handler:settings:notifications:description' => "Cuando active esta opción, todas las notificaciones hacia los usuarios de su sitio web serán formateadas en HTML.",
		'html_email_handler:settings:notifications' => "Usar como el manejador de notificaciones de correo predeterminado",
		'html_email_handler:settings:notifications:subtext' => "Se enviarán todos los mails de salida con formato HTML",
		
		'html_email_handler:settings:sendmail_options' => "Parámetros adicionales de sendmail (opcionales)",
		'html_email_handler:settings:sendmail_options:description' => "Aquí podrás configurar opciones del software sendmail, por ejemplo -f %s (para prevenir mejor los mails detectados como spam)",
		
		// notification body - cuerpo del correo
		'html_email_handler:notification:footer:settings' => "Configurar los seteos de las configuraciones %saqui%s",
	
	);
	
	add_translation("es", $spa);
